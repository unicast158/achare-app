import React from 'react';

const Cleaning = () => {
    return (
        <div>
            Cleaning
        </div>
    );
};

export default Cleaning;