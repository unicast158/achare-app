import React from 'react';

const CustomList = ({data}) => {
    return (
        <div>
            {/*{data.map(item)} */}
        </div>
    );
};

export default CustomList;
