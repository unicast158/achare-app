import React from 'react';
import Navbar_react from "../Header/Navbar/Navbar";


const LandingHeader = () => {
    return (
        <div>
            <Navbar_react/>
        </div>
    );
};

export default LandingHeader;